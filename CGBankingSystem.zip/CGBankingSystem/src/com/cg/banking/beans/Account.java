package com.cg.banking.beans;

import java.util.HashMap;
import java.util.Map;

public class Account {

	private int accountNo;
	private String accountType;
	private float accountBalance;
	private int pinNumber;
	private String status;
	private int pinCounter;
	private Map<Integer, Transaction> transactions=new HashMap<Integer, Transaction>();

	
	public Account(int i, String string, int j, int k, String string2, int l, Transaction transaction) {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(int accountNo, String accountType, float accountBalance,
			int pinNumber, String status, int pinCounter,
			Map<Integer, Transaction> transactions) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.pinNumber = pinNumber;
		this.status = status;
		this.pinCounter = pinCounter;
		this.transactions = transactions;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getPinCounter() {
		return pinCounter;
	}
	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}
	public Map<Integer, Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(Map<Integer, Transaction> transactions) {
		this.transactions = transactions;
	}
	
	
}
