package com.cg.banking.beans;
public class Address {
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	private int pincode;
	private String city,state;
	public Address(int pincode, String city, String state) {
		super();
		this.pincode = pincode;
		this.city = city;
		this.state = state;
	}
	
	
}