package com.cg.banking.beans;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Customer {
	
	private int customerId;
	private String firstName,lastName,emailId,panCard;
	private String password;
	private List<Address>addresses;
	Map<Integer, Account> accounts=new HashMap<>();
	
	
	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getPanCard() {
		return panCard;
	}


	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public List<Address> getAddresses() {
		return addresses;
	}


	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}


	public Map<Integer, Account> getAccounts() {
		return accounts;
	}


	public void setAccounts(Map<Integer, Account> accounts) {
		this.accounts = accounts;
	}


	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Customer(int customerId, String firstName, String lastName,
			String emailId, String panCard, String password,
			Address addresses, Account accounts) {
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.panCard = panCard;
		this.password = password;
		this.addresses =  (List<Address>) addresses;
		this.accounts = (Map<Integer, Account>) accounts;
	}


	public Customer(int i, String string, String string2, String string3,
			String string4, String string5, String string6, Account account) {
		// TODO Auto-generated constructor stub
	}

	
}
