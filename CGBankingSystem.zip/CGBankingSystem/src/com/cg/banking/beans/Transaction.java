package com.cg.banking.beans;
public class Transaction {
	private int transactionId;
	private float amount;
	public Transaction(int transactionId, float amount, String transactionType) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
		this.transactionType = transactionType;
	}
	private String transactionType;
	
}