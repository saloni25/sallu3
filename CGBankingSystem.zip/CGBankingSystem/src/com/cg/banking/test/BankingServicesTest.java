package com.cg.banking.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class BankingServicesTest {
	
	private static BankingServices bankingServices;
	
	@BeforeClass
	public static void setUpBankingServices(){
		bankingServices = new BankingServicesImpl();
	}
	
	@Before
	public void setUpTestData(){
	

		BankingDAOServicesImpl.customer.put(1000, new Customer(1000,"satish","mahajan","sm@capgi.com","ABCD1234","abcd","Pune",new Account(1, "SAVINGS", 5000, 1234, "ACTIVE" , 0, new Transaction(1, 1000, "DEPOSIT"))));
		BankingDAOServicesImpl.customer.put(1001, new Customer(1001,"monica","dabas","md@capgi.com","ABASH234","tyrt","Pune",new Account(2, "CURRENT", 6000, 4234, "ACTIVE" , 0, new Transaction(2, 6000, "WITHDRAW"))));
		BankingDAOServicesImpl.CUSTOMER_ID_COUNTER =1001;
		BankingDAOServicesImpl.ACCOUNT_ID_COUNTER=2;
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testgetCustomerDetailsForInvalidcustomerid()throws BankingServicesDownException ,  CustomerNotFoundException{
		bankingServices.getCustomerDetails(14346);
	}
	
	@Test
	public void testgetCustomerDetailsForValidCustomerid() throws CustomerNotFoundException, BankingServicesDownException{
		Customer expectedCustomer = new Customer(1000,"satish","mahajan","sm@capgi.com","ABCD1234","abcd","Pune",new Account(1, "SAVINGS", 5000, 1234, "ACTIVE" , 0, new Transaction(1, 1000, "DEPOSIT")));
		Customer actualCustomer= bankingServices.getCustomerDetails(1000);
		assertEquals(expectedCustomer,actualCustomer);
	}
	@Test(expected=InvalidAmountException.class)
	public void testOpenAccountforInvalidAccountBalance() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(-1234,"savings");
		
		
		
	}
	
	@Test
	public void testOpenAccountforValidAccountBalance() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		int expectedAccountId =3;
		int actualAccountId =bankingServices.openAccount(2345, "savings");
		assertEquals(expectedAccountId, actualAccountId);
	}
	
	@Test(expected=InvalidAccountTypeException.class)
	public void testOpenAccountforInvalidAccountType() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException
	{
		bankingServices.openAccount(12322, "abc");
	}
	

	@Test
	public void testDepositAmountforInvalidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException
	{
	bankingServices.depositAmount(1006, 11234, 200000);
	}
	
	
	@Test
	public void testDepositAmountforValidCustomerID() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException
	{
		
		int expectedCustomerId=1000;
		int actualCustomerId=bankingServices.depositAmount(1000, 1234, 20000);
		assertEquals(expectedCustomerId, actualCustomerId);
		
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testDepositAmountforInValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException
	{
		bankingServices.depositAmount(1000, 1222, 12000);
	}
	
	@Test
	public void testDepositAmountforValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException
	{
		int expectedAccountNo=1234;
		int actualAccountNo= bankingServices.depositAmount(1000, 1234, 25000);
		assertEquals(expectedAccountNo, actualAccountNo);
		
	}
	
	
	@Test(expected=CustomerNotFoundException.class)
	public void testWithdrawAmountforInvalidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException
	{
	bankingServices.withdrawAmount(1006, 1234, 100000, 0);
	}
	
	
	@Test
	public void testWithdrawAmountforValidCustomerID() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException
	{
		
		int expectedCustomerId=1000;
		int actualCustomerId=bankingServices.withdrawAmount(1000, 1234, 10000, 0);
		assertEquals(expectedCustomerId, actualCustomerId);
		
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testWithdrawAmountforInValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException
	{
		bankingServices.withdrawAmount(1000, 1111, 12123, 0);
	}
	
	@Test
	public void testWithdrawAmountforValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException
	{
		int expectedAccountNo=1234;
		int actualAccountNo= bankingServices.withdrawAmount(1000, 1234, 33554, 0);
		assertEquals(expectedAccountNo, actualAccountNo);
		
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testFundTransferforInvalidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException
	{
	bankingServices.fundTransfer(1000, 1234, 1111, 4234, 12332,0);
	}
	
	
	@Test
	public void testfundTransferforValidCustomerID() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException
	{
		
		int expectedCustomerId=1000;
		boolean actualCustomerId=bankingServices.fundTransfer(1000, 1234, 1001, 4234, 12332,0);
		assertEquals(expectedCustomerId, actualCustomerId);
		
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testFundTransferforInValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException
	{
		bankingServices.fundTransfer(1000, 1234, 1001, 2222, 34554, 0);
	}
	
	@Test
	public void testFundTransferforValidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException
	{
		int expectedAccountNo=1234;
		boolean actualAccountNo= bankingServices.fundTransfer(1000, 1234, 1001, 4234, 12332,0);
		assertEquals(expectedAccountNo, actualAccountNo);
		
	}
	

		
	
	}
	
	
	
	
	
	