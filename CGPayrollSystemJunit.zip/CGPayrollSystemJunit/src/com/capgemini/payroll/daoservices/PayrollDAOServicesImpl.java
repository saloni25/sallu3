package com.capgemini.payroll.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.capgemini.payroll.beans.Associate;
import com.capgemini.payroll.beans.BankDetails;
import com.capgemini.payroll.beans.Salary;
import com.capgemini.payroll.exception.PayrollServicesDownException;
import com.capgemini.payroll.provider.ServiceProvider;
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	
	public  static HashMap<Integer, Associate> associates = new HashMap<>();
	public static int ASSOCIATE_ID_COUNTER =1000;

	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		
		return 0;
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
	
		return false;
	}

	@Override
	public boolean deleteAssciate(int associateId) throws SQLException {
		
		return false;
	}

	@Override
	public Associate getAssociate(int associateId) throws SQLException {
		
		return null;
	}

	@Override
	public List<Associate> getAssociates() throws SQLException {
		
		return null;
	}

	
}
